# Importa as bibliotecas necessárias
import pandas as pd           # Para manipulação de dados em DataFrames
import sqlite3                # Para interação com banco de dados SQLite

# Lê os dados do CSV para um DataFrame
df = pd.read_csv("dataset/diabetes.csv")

# Conecta (ou cria) um banco de dados SQLite
cnn = sqlite3.connect('database/diabetes.db')

# Insere os dados do DataFrame na tabela 'diabetes' no banco SQLite
# Se a tabela já existir, ela será substituída
df.to_sql('diabetes', cnn, if_exists='replace')

# Cria um cursor para executar comandos SQL
cursor = cnn.cursor()

# Cria a tabela 'pacientes' se ela ainda não existir
cursor.execute("""
    CREATE TABLE IF NOT EXISTS pacientes (
        Pregnancies INT,
        Glucose INT,
        BloodPressure INT,
        SkinThickness INT,
        Insulin INT,
        BMI DECIMAL(8,2),
        DiabetesPedigreeFunction DECIMAL(8,2),
        Age INT,
        Outcome INT
    )
""")

# Verifica quantos registros existem atualmente na tabela 'pacientes'
cursor.execute("SELECT COUNT(*) FROM pacientes")
total_registros = cursor.fetchone()[0]  # Retorna o valor da contagem

# Se a tabela estiver vazia, insere pacientes com idade > 50 da tabela 'diabetes'
if total_registros == 0:
    print("A tabela está vazia. Inserindo dados...")
    cursor.execute("""
        INSERT INTO pacientes (
            Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI,
            DiabetesPedigreeFunction, Age, Outcome
        )
        SELECT
            Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI,
            DiabetesPedigreeFunction, Age, Outcome
        FROM diabetes
        WHERE Age > 50
    """)
else:
    # Se já houver dados, informa a quantidade
    print(f"A tabela já possui {total_registros} registros. Nenhuma inserção feita.")

# Tenta adicionar a coluna 'PERFIL' à tabela, se ela ainda não existir
try:
    cursor.execute("ALTER TABLE pacientes ADD PERFIL VARCHAR(10)")
except sqlite3.OperationalError:
    # Se a coluna já existir, captura o erro e avisa
    print("A coluna PERFIL já existe.")

# Atualiza os valores da coluna PERFIL com base nos intervalos de IMC (BMI)
cursor.execute("UPDATE pacientes SET PERFIL = 'Normal' WHERE BMI < 30")
cursor.execute("UPDATE pacientes SET PERFIL = 'Sobrepeso' WHERE BMI >= 30 AND BMI < 35")
cursor.execute("UPDATE pacientes SET PERFIL = 'Obesidade' WHERE BMI >= 35")

# Consulta todos os dados da tabela 'pacientes'
cursor.execute("SELECT * FROM pacientes")

# Captura os nomes das colunas para usar como cabeçalho no DataFrame
cols = [column[0] for column in cursor.description]

# Cria um DataFrame com os dados recuperados
resultado = pd.DataFrame.from_records(data=cursor.fetchall(), columns=cols)

# Exibe as 5 primeiras linhas
print(resultado.head())

# Salva o DataFrame final em um novo arquivo CSV
resultado.to_csv("dataset/pacientes.csv", index=False)

# Salva alterações no banco de dados e fecha a conexão
cnn.commit()
cnn.close()
